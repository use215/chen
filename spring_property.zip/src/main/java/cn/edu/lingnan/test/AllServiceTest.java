package cn.edu.lingnan.test;

public class AllServiceTest {

}
