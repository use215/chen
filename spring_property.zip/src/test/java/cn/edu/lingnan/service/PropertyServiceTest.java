//package cn.edu.lingnan.service;
//
//import cn.edu.lingnan.pojo.Property;
//import org.junit.Test;
//
//public class PropertyServiceTest {
//    PropertyService service = new PropertyServiceMysqlImpl();
//    @Test
//    public void updateProject(){
//        Property property = new Property("r05","算法",1);
//        System.out.println(service.updateRace(property));
//    }
//}
